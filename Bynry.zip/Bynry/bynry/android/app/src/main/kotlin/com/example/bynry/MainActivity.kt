package com.example.bynry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
